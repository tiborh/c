/****************************************************************************
 * math1.c
 *
 * David J. Malan
 * malan@harvard.edu
 *
 * Computes a total but does nothing with it.
 *
 * Demonstrates use of variables.
 ***************************************************************************/

#include <stdio.h>

int main(void)
{
    int x = 1;
    int y = 2;
    int z = x + y;
    return 0;
}
